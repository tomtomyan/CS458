function comment() {
  if (window.location.href.indexOf("view.php") == -1) return
  const urlParams = new URLSearchParams(window.location.search);
  document.getElementById("author").innerHTML = 'posted by AGoldmund'
  return urlParams.get('id');
}
