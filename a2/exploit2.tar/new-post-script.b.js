$.post('post.php',
  {
    title: 'very important',
    content: 'Down with CipherIsland!!',
    type: '1',
    form: 'content'
  })
